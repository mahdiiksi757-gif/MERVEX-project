/* ============================================================
   MERVEX — ONLINE SHOPPING — script.js
   ============================================================ */

// ---------- PRODUCT DATABASE ----------
const products = [
  { id: 1,  name: "MERVEX BLACK WATCH",   category: "watches",     price: 899, oldPrice: 1099, image: "./assets/images/watches/watch-01.svg",     rating: 4.9, colors: ["Black","Silver"], sizes: [],                bestseller: true,  newProduct: false, discount: 18 },
  { id: 2,  name: "MERVEX CLASSIC WATCH", category: "watches",     price: 999, oldPrice: 1199, image: "./assets/images/watches/watch-02.svg",     rating: 4.7, colors: ["Silver","Black"],  sizes: [],                bestseller: true,  newProduct: false, discount: 17 },
  { id: 3,  name: "MERVEX URBAN CAP",     category: "caps",        price: 149, oldPrice: 199,  image: "./assets/images/caps/cap-01.svg",          rating: 4.8, colors: ["Black","White"],   sizes: ["S/M","L/XL"],   bestseller: true,  newProduct: false, discount: 25 },
  { id: 4,  name: "MERVEX SNAPBACK",      category: "caps",        price: 169, oldPrice: 0,    image: "./assets/images/caps/cap-02.svg",          rating: 4.6, colors: ["Black"],            sizes: ["One Size"],     bestseller: false, newProduct: true,  discount: 0  },
  { id: 5,  name: "MERVEX STREET BAG",    category: "bags",        price: 399, oldPrice: 499,  image: "./assets/images/bags/bag-01.svg",          rating: 4.9, colors: ["Black"],            sizes: [],                bestseller: true,  newProduct: false, discount: 20 },
  { id: 6,  name: "MERVEX SHOULDER BAG",  category: "bags",        price: 449, oldPrice: 0,    image: "./assets/images/bags/bag-02.svg",          rating: 4.5, colors: ["Black","Silver"],  sizes: [],                bestseller: false, newProduct: true,  discount: 0  },
  { id: 7,  name: "MERVEX SIGNATURE BELT",category: "accessories", price: 249, oldPrice: 299,  image: "./assets/images/accessories/acc-01.svg",   rating: 4.4, colors: ["Black"],            sizes: ["S","M","L"],    bestseller: false, newProduct: false, discount: 17 },
  { id: 8,  name: "MERVEX CARD HOLDER",   category: "accessories", price: 179, oldPrice: 0,    image: "./assets/images/accessories/acc-02.svg",   rating: 4.3, colors: ["Black","White"],   sizes: [],                bestseller: false, newProduct: true,  discount: 0  },
  { id: 9,  name: "MERVEX CHRONO WATCH",  category: "watches",     price: 1099,oldPrice: 1299, image: "./assets/images/watches/watch-01.svg",     rating: 5.0, colors: ["Black"],            sizes: [],                bestseller: false, newProduct: true,  discount: 15 },
  { id: 10, name: "MERVEX TRUCKER CAP",   category: "caps",        price: 139, oldPrice: 0,    image: "./assets/images/caps/cap-01.svg",          rating: 4.2, colors: ["White","Black"],   sizes: ["One Size"],     bestseller: false, newProduct: false, discount: 0  },
  { id: 11, name: "MERVEX TOTE BAG",      category: "bags",        price: 329, oldPrice: 379,  image: "./assets/images/bags/bag-01.svg",          rating: 4.6, colors: ["Black"],            sizes: [],                bestseller: false, newProduct: false, discount: 13 },
  { id: 12, name: "MERVEX SILVER WATCH",  category: "watches",     price: 949, oldPrice: 0,    image: "./assets/images/watches/watch-02.svg",     rating: 4.7, colors: ["Silver"],           sizes: [],                bestseller: false, newProduct: true,  discount: 0  },
];

const reviews = [
  { text: "Très bonne qualité et livraison rapide.", author: "Yassine M." },
  { text: "Le produit est encore plus beau en vrai.", author: "Adam R." },
  { text: "Packaging très propre et professionnel.", author: "Mehdi A." },
  { text: "Service client réactif sur WhatsApp, je recommande.", author: "Salma K." },
  { text: "Ma casquette MERVEX est devenue mon accessoire préféré.", author: "Imane B." },
  { text: "Montre élégante, exactement comme sur les photos.", author: "Yassir T." },
];

const WHATSAPP_NUMBER = "212611115043";
const DELIVERY_FEE = 30;
const API_BASE = "/api";
async function apiJSON(url, options = {}) {
  const res = await fetch(url, { headers: {"Content-Type":"application/json"}, ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Erreur serveur");
  return data;
}
async function loadProductsFromAPI(){
  try {
    const remote = await apiJSON(`${API_BASE}/products`);
    if (Array.isArray(remote) && remote.length) {
      products.splice(0, products.length, ...remote);
    }
  } catch (e) {
    console.warn("API indisponible, catalogue local utilisé.", e);
  }
}

// ---------- STATE ----------
let cart = JSON.parse(localStorage.getItem("mervex_cart") || "[]");
let wishlist = JSON.parse(localStorage.getItem("mervex_wishlist") || "[]");
let activeFilters = { category: "all", price: 2000, colors: [], rating: 0, sort: "featured", query: "" };
let currentQVProduct = null;
let qvSelection = { color: null, size: null, qty: 1 };
let checkoutStep = 1;
let checkoutData = {};

// ---------- HELPERS ----------
function saveCart(){ localStorage.setItem("mervex_cart", JSON.stringify(cart)); }
function saveWishlist(){ localStorage.setItem("mervex_wishlist", JSON.stringify(wishlist)); }
function formatMAD(n){ return `${n.toLocaleString("fr-FR")} MAD`; }
function findProduct(id){ return products.find(p => p.id === id); }
function starString(rating){
  const full = Math.round(rating);
  return "★".repeat(full) + "☆".repeat(5 - full);
}
function waLink(message){
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function showToast(message){
  const wrap = document.getElementById("toastWrap");
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

// ============================================================
// PRODUCT RENDERING
// ============================================================
function productCardHTML(p){
  const inWishlist = wishlist.includes(p.id);
  return `
  <article class="product-card reveal" data-id="${p.id}">
    <div class="product-card__media">
      <div class="product-card__badges">
        ${p.bestseller ? '<span class="badge">Bestseller</span>' : ''}
        ${p.newProduct ? '<span class="badge badge--new">New</span>' : ''}
        ${p.discount > 0 ? `<span class="badge badge--new">-${p.discount}%</span>` : ''}
      </div>
      <button class="product-card__wish ${inWishlist ? 'is-active' : ''}" data-wish="${p.id}" aria-label="Ajouter aux favoris">
        <svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-10-9C.3 8.1 2 4 6 4c2.2 0 3.9 1.3 6 3.6C14.1 5.3 15.8 4 18 4c4 0 5.7 4.1 4 8-2.5 4.4-10 9-10 9z"/></svg>
      </button>
      <img src="${p.image}" alt="${p.name}" loading="lazy">
      <button class="product-card__quick" data-quickview="${p.id}">Quick View</button>
    </div>
    <div class="product-card__body">
      <span class="product-card__cat">${p.category}</span>
      <h3 class="product-card__name">${p.name}</h3>
      <div class="product-card__rating">${starString(p.rating)} <span>${p.rating}</span></div>
      <div class="product-card__price">
        <strong>${formatMAD(p.price)}</strong>
        ${p.oldPrice ? `<span class="old">${formatMAD(p.oldPrice)}</span>` : ''}
        ${p.discount > 0 ? `<span class="discount">-${p.discount}%</span>` : ''}
      </div>
      <button class="product-card__add" data-addcart="${p.id}">Add to Cart</button>
    </div>
  </article>`;
}

function getFilteredProducts(){
  let list = [...products];
  const f = activeFilters;

  if (f.query){
    const q = f.query.toLowerCase();
    list = list.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.category === "bags" && "bag".includes(q)) ||
      (p.category === "watches" && "watch".includes(q)) ||
      (p.category === "caps" && "cap".includes(q))
    );
  }
  if (f.category !== "all") list = list.filter(p => p.category === f.category);
  list = list.filter(p => p.price <= f.price);
  if (f.colors.length) list = list.filter(p => p.colors.some(c => f.colors.includes(c)));
  if (f.rating > 0) list = list.filter(p => p.rating >= f.rating);

  switch (f.sort){
    case "newest": list.sort((a,b) => b.newProduct - a.newProduct); break;
    case "price-asc": list.sort((a,b) => a.price - b.price); break;
    case "price-desc": list.sort((a,b) => b.price - a.price); break;
    case "rating": list.sort((a,b) => b.rating - a.rating); break;
    default: list.sort((a,b) => b.bestseller - a.bestseller);
  }
  return list;
}

function renderProductGrid(){
  const grid = document.getElementById("productGrid");
  const list = getFilteredProducts();
  const noResults = document.getElementById("noResults");

  grid.innerHTML = list.map(productCardHTML).join("");
  noResults.hidden = list.length > 0;
  grid.style.display = list.length > 0 ? "grid" : "none";

  attachCardListeners(grid);
  observeReveals();
}

function renderNewArrivals(){
  const grid = document.getElementById("newGrid");
  const list = products.filter(p => p.newProduct);
  grid.innerHTML = list.map(productCardHTML).join("");
  attachCardListeners(grid);
  observeReveals();
}

function attachCardListeners(container){
  container.querySelectorAll("[data-addcart]").forEach(btn => {
    btn.addEventListener("click", () => addToCart(parseInt(btn.dataset.addcart)));
  });
  container.querySelectorAll("[data-wish]").forEach(btn => {
    btn.addEventListener("click", () => toggleWishlist(parseInt(btn.dataset.wish)));
  });
  container.querySelectorAll("[data-quickview]").forEach(btn => {
    btn.addEventListener("click", () => openQuickView(parseInt(btn.dataset.quickview)));
  });
}

// ============================================================
// CART
// ============================================================
function addToCart(id, color = null, size = null, qty = 1){
  const p = findProduct(id);
  if (!p) return;
  const key = `${id}-${color || ''}-${size || ''}`;
  const existing = cart.find(c => c.key === key);
  if (existing){
    existing.qty += qty;
  } else {
    cart.push({ key, id, color: color || (p.colors[0] || null), size: size || (p.sizes[0] || null), qty });
  }
  saveCart();
  renderCart();
  showToast("Added to cart ✓");
}

function updateCartQty(key, delta){
  const item = cart.find(c => c.key === key);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0){
    cart = cart.filter(c => c.key !== key);
    showToast("Product removed");
  }
  saveCart();
  renderCart();
}

function removeFromCart(key){
  cart = cart.filter(c => c.key !== key);
  saveCart();
  renderCart();
  showToast("Product removed");
}

function cartSubtotal(){
  return cart.reduce((sum, item) => {
    const p = findProduct(item.id);
    return sum + (p ? p.price * item.qty : 0);
  }, 0);
}

function renderCart(){
  const wrap = document.getElementById("cartItems");
  const empty = document.getElementById("cartEmpty");
  const summary = document.getElementById("cartSummary");
  const countBadge = document.getElementById("cartCount");
  const totalQty = cart.reduce((s,c) => s + c.qty, 0);

  countBadge.textContent = totalQty;
  countBadge.classList.toggle("is-visible", totalQty > 0);

  if (cart.length === 0){
    wrap.innerHTML = "";
    empty.hidden = false;
    summary.style.display = "none";
    return;
  }
  empty.hidden = true;
  summary.style.display = "block";

  wrap.innerHTML = cart.map(item => {
    const p = findProduct(item.id);
    if (!p) return "";
    return `
    <div class="cart-item" data-key="${item.key}">
      <img src="${p.image}" alt="${p.name}">
      <div class="cart-item__info">
        <span class="cart-item__name">${p.name}</span>
        <span class="cart-item__price">${item.color || ''} ${item.size ? '· ' + item.size : ''}</span>
        <span class="cart-item__price">${formatMAD(p.price)}</span>
        <div class="cart-item__qty">
          <button data-qty-minus="${item.key}">−</button>
          <span>${item.qty}</span>
          <button data-qty-plus="${item.key}">+</button>
        </div>
        <button class="cart-item__remove" data-remove="${item.key}">Remove</button>
      </div>
    </div>`;
  }).join("");

  wrap.querySelectorAll("[data-qty-plus]").forEach(b => b.addEventListener("click", () => updateCartQty(b.dataset.qtyPlus, 1)));
  wrap.querySelectorAll("[data-qty-minus]").forEach(b => b.addEventListener("click", () => updateCartQty(b.dataset.qtyMinus, -1)));
  wrap.querySelectorAll("[data-remove]").forEach(b => b.addEventListener("click", () => removeFromCart(b.dataset.remove)));

  const subtotal = cartSubtotal();
  document.getElementById("cartSubtotal").textContent = formatMAD(subtotal);
  document.getElementById("cartDelivery").textContent = formatMAD(DELIVERY_FEE);
  document.getElementById("cartTotal").textContent = formatMAD(subtotal + DELIVERY_FEE);
}

// ============================================================
// WISHLIST
// ============================================================
function toggleWishlist(id){
  if (wishlist.includes(id)){
    wishlist = wishlist.filter(w => w !== id);
    showToast("Product removed");
  } else {
    wishlist.push(id);
    showToast("Added to wishlist ♥");
  }
  saveWishlist();
  renderWishlist();
  renderProductGrid();
  renderNewArrivals();
}

function renderWishlist(){
  const wrap = document.getElementById("wishlistItems");
  const empty = document.getElementById("wishlistEmpty");
  const countBadge = document.getElementById("wishlistCount");

  countBadge.textContent = wishlist.length;
  countBadge.classList.toggle("is-visible", wishlist.length > 0);

  if (wishlist.length === 0){
    wrap.innerHTML = "";
    empty.hidden = false;
    return;
  }
  empty.hidden = true;

  wrap.innerHTML = wishlist.map(id => {
    const p = findProduct(id);
    if (!p) return "";
    return `
    <div class="wishlist-item" data-id="${p.id}">
      <img src="${p.image}" alt="${p.name}">
      <div class="wishlist-item__info">
        <span class="wishlist-item__name">${p.name}</span>
        <span class="cart-item__price">${formatMAD(p.price)}</span>
        <button class="wishlist-item__add" data-wadd="${p.id}">Add to Cart</button>
        <button class="wishlist-item__remove" data-wremove="${p.id}">Remove</button>
      </div>
    </div>`;
  }).join("");

  wrap.querySelectorAll("[data-wadd]").forEach(b => b.addEventListener("click", () => addToCart(parseInt(b.dataset.wadd))));
  wrap.querySelectorAll("[data-wremove]").forEach(b => b.addEventListener("click", () => toggleWishlist(parseInt(b.dataset.wremove))));
}

// ============================================================
// QUICK VIEW MODAL
// ============================================================
function openQuickView(id){
  const p = findProduct(id);
  if (!p) return;
  currentQVProduct = p;
  qvSelection = { color: p.colors[0] || null, size: p.sizes[0] || null, qty: 1 };
  renderQuickView();
  openModal("quickView");
}

function renderQuickView(){
  const p = currentQVProduct;
  if (!p) return;
  const content = document.getElementById("qvContent");
  content.innerHTML = `
    <div class="qv__media"><img src="${p.image}" alt="${p.name}"></div>
    <div class="qv__info">
      <span class="product-card__cat">${p.category}</span>
      <h3>${p.name}</h3>
      <div class="product-card__rating">${starString(p.rating)} <span>${p.rating}</span></div>
      <div class="price-row">
        <strong>${formatMAD(p.price)}</strong>
        ${p.oldPrice ? `<span class="old">${formatMAD(p.oldPrice)}</span>` : ''}
      </div>
      <p class="qv__desc">Pièce signature MERVEX : fabrication premium, finitions noires et argentées, pensée pour un usage quotidien street style. Livraison partout au Maroc.</p>
      ${p.colors.length ? `
      <div class="qv__row">
        <label>Color</label>
        <div class="qv__swatches">
          ${p.colors.map(c => `<button class="qv__swatch ${c === qvSelection.color ? 'is-active' : ''}" data-color="${c}" style="background:${c === 'Black' ? '#111' : c === 'White' ? '#eee' : '#aaa'}" title="${c}"></button>`).join("")}
        </div>
      </div>` : ''}
      ${p.sizes.length ? `
      <div class="qv__row">
        <label>Size</label>
        <div class="qv__sizes">
          ${p.sizes.map(s => `<button class="qv__size ${s === qvSelection.size ? 'is-active' : ''}" data-size="${s}">${s}</button>`).join("")}
        </div>
      </div>` : ''}
      <div class="qv__row">
        <label>Quantity</label>
        <div class="qv__qty">
          <button id="qvQtyMinus">−</button>
          <span id="qvQtyVal">${qvSelection.qty}</span>
          <button id="qvQtyPlus">+</button>
        </div>
      </div>
      <div class="qv__actions">
        <button class="btn btn--primary" id="qvAddCart">Add to Cart</button>
        <button class="btn btn--ghost" id="qvBuyNow">Buy Now</button>
        <button class="btn btn--outline" id="qvWishlist">${wishlist.includes(p.id) ? '♥ In Wishlist' : '♡ Add to Wishlist'}</button>
      </div>
    </div>
  `;

  content.querySelectorAll("[data-color]").forEach(b => b.addEventListener("click", () => { qvSelection.color = b.dataset.color; renderQuickView(); }));
  content.querySelectorAll("[data-size]").forEach(b => b.addEventListener("click", () => { qvSelection.size = b.dataset.size; renderQuickView(); }));
  const qtyMinus = document.getElementById("qvQtyMinus");
  const qtyPlus = document.getElementById("qvQtyPlus");
  if (qtyMinus) qtyMinus.addEventListener("click", () => { if (qvSelection.qty > 1) qvSelection.qty--; renderQuickView(); });
  if (qtyPlus) qtyPlus.addEventListener("click", () => { qvSelection.qty++; renderQuickView(); });

  document.getElementById("qvAddCart").addEventListener("click", () => {
    addToCart(p.id, qvSelection.color, qvSelection.size, qvSelection.qty);
  });
  document.getElementById("qvBuyNow").addEventListener("click", () => {
    addToCart(p.id, qvSelection.color, qvSelection.size, qvSelection.qty);
    closeModal("quickview");
    openCheckout();
  });
  document.getElementById("qvWishlist").addEventListener("click", () => {
    toggleWishlist(p.id);
    renderQuickView();
  });
}

// ============================================================
// MODAL SYSTEM (generic open/close)
// ============================================================
const modalIds = { quickview: "quickView", account: "accountModal", checkout: "checkoutModal", gift: "giftModal" };

function openModal(id){
  document.getElementById(id).classList.add("is-open");
  document.getElementById(id).setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}
function closeModal(key){
  const id = modalIds[key] || key;
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.remove("is-open");
  el.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function openDrawer(id){
  document.getElementById(id).classList.add("is-open");
  document.getElementById("overlay").classList.add("is-open");
  document.body.style.overflow = "hidden";
}
function closeDrawer(key){
  const id = key === "cart" ? "cartDrawer" : "wishlistDrawer";
  document.getElementById(id).classList.remove("is-open");
  document.getElementById("overlay").classList.remove("is-open");
  document.body.style.overflow = "";
}
function closeAllOverlays(){
  document.querySelectorAll(".drawer").forEach(d => d.classList.remove("is-open"));
  document.getElementById("overlay").classList.remove("is-open");
  document.getElementById("mobileMenu").classList.remove("is-open");
  document.getElementById("burgerBtn").classList.remove("is-active");
  document.body.style.overflow = "";
}

// ============================================================
// CHECKOUT
// ============================================================
const MOROCCAN_CITIES = ["Casablanca","Rabat","Marrakech","Tangier","Agadir","Fes","Meknes","Oujda","Kenitra","Tetouan"];

function openCheckout(){
  if (cart.length === 0){
    showToast("Your cart is empty");
    return;
  }
  checkoutStep = 1;
  checkoutData = { payment: "cod" };
  renderCheckout();
  closeDrawer("cart");
  openModal("checkoutModal");
}

function checkoutStepsHTML(){
  const labels = ["Info", "Delivery", "Payment", "Confirm"];
  return `<div class="checkout__steps">${labels.map((l,i) => `<span class="${i+1 === checkoutStep ? 'is-active' : ''}">${l}</span>`).join("")}</div>`;
}

function renderCheckout(){
  const el = document.getElementById("checkoutContent");
  const subtotal = cartSubtotal();
  const total = subtotal + DELIVERY_FEE;

  if (checkoutStep === 1){
    el.innerHTML = `
      ${checkoutStepsHTML()}
      <h3>Customer Information</h3>
      <div class="checkout__grid">
        <div><label>First Name</label><input id="cFirst" value="${checkoutData.first || ''}"></div>
        <div><label>Last Name</label><input id="cLast" value="${checkoutData.last || ''}"></div>
        <div><label>Phone</label><input id="cPhone" value="${checkoutData.phone || ''}"></div>
        <div><label>Email</label><input id="cEmail" type="email" value="${checkoutData.email || ''}"></div>
      </div>
      <div class="checkout__nav">
        <span></span>
        <button class="btn btn--primary" id="toStep2">Continue</button>
      </div>`;
    document.getElementById("toStep2").addEventListener("click", () => {
      checkoutData.first = document.getElementById("cFirst").value;
      checkoutData.last = document.getElementById("cLast").value;
      checkoutData.phone = document.getElementById("cPhone").value;
      checkoutData.email = document.getElementById("cEmail").value;
      if (!checkoutData.first || !checkoutData.phone){ showToast("Please fill in required fields"); return; }
      checkoutStep = 2; renderCheckout();
    });
  }

  else if (checkoutStep === 2){
    el.innerHTML = `
      ${checkoutStepsHTML()}
      <h3>Delivery Address</h3>
      <div class="checkout__grid">
        <div class="full"><label>City</label>
          <select id="cCity">${MOROCCAN_CITIES.map(c => `<option ${checkoutData.city === c ? 'selected' : ''}>${c}</option>`).join("")}</select>
        </div>
        <div class="full"><label>Address</label><input id="cAddress" value="${checkoutData.address || ''}"></div>
        <div><label>Postal Code</label><input id="cPostal" value="${checkoutData.postal || ''}"></div>
      </div>
      <div class="checkout__nav">
        <button class="btn btn--ghost" id="toStep1">Back</button>
        <button class="btn btn--primary" id="toStep3">Continue</button>
      </div>`;
    document.getElementById("toStep1").addEventListener("click", () => { checkoutStep = 1; renderCheckout(); });
    document.getElementById("toStep3").addEventListener("click", () => {
      checkoutData.city = document.getElementById("cCity").value;
      checkoutData.address = document.getElementById("cAddress").value;
      checkoutData.postal = document.getElementById("cPostal").value;
      if (!checkoutData.address){ showToast("Please enter your address"); return; }
      checkoutStep = 3; renderCheckout();
    });
  }

  else if (checkoutStep === 3){
    el.innerHTML = `
      ${checkoutStepsHTML()}
      <h3>Payment</h3>
      <div class="checkout__pay">
        <label class="pay-option ${checkoutData.payment === 'cod' ? 'is-active' : ''}">
          <input type="radio" name="pay" value="cod" ${checkoutData.payment === 'cod' ? 'checked' : ''}> Cash on Delivery
        </label>
        <label class="pay-option ${checkoutData.payment === 'visa' ? 'is-active' : ''}">
          <input type="radio" name="pay" value="visa" ${checkoutData.payment === 'visa' ? 'checked' : ''}> Visa
        </label>
        <label class="pay-option ${checkoutData.payment === 'mastercard' ? 'is-active' : ''}">
          <input type="radio" name="pay" value="mastercard" ${checkoutData.payment === 'mastercard' ? 'checked' : ''}> Mastercard
        </label>
      </div>
      <div class="checkout__summary"><span>Subtotal</span><span>${formatMAD(subtotal)}</span></div>
      <div class="checkout__summary"><span>Delivery</span><span>${formatMAD(DELIVERY_FEE)}</span></div>
      <div class="checkout__summary total"><span>Total</span><span>${formatMAD(total)}</span></div>
      <div class="checkout__nav">
        <button class="btn btn--ghost" id="toStep2b">Back</button>
        <button class="btn btn--primary" id="placeOrder">Place Order</button>
      </div>`;
    el.querySelectorAll('input[name="pay"]').forEach(r => r.addEventListener("change", (e) => { checkoutData.payment = e.target.value; renderCheckout(); }));
    document.getElementById("toStep2b").addEventListener("click", () => { checkoutStep = 2; renderCheckout(); });
    document.getElementById("placeOrder").addEventListener("click", async () => {
      const btn = document.getElementById("placeOrder");
      btn.disabled = true;
      try {
        const order = await apiJSON(`${API_BASE}/orders`, {
          method: "POST",
          body: JSON.stringify({
            customer: {
              first: checkoutData.first || "",
              last: checkoutData.last || "",
              phone: checkoutData.phone || "",
              email: checkoutData.email || "",
              city: checkoutData.city || "",
              address: checkoutData.address || "",
              postal: checkoutData.postal || ""
            },
            payment: checkoutData.payment || "cod",
            deliveryFee: DELIVERY_FEE,
            items: cart.map(item => ({
              productId: item.id,
              qty: item.qty
            }))
          })
        });
        checkoutData.orderId = order.id;
        checkoutStep = 4; renderCheckout();
        cart = []; saveCart(); renderCart();
        showToast("Order confirmed");
      } catch (e) {
        btn.disabled = false;
        showToast(e.message || "Impossible d'enregistrer la commande");
      }
    });
  }

  else if (checkoutStep === 4){
    const orderMsg = `Bonjour MERVEX, je viens de passer une commande (${formatMAD(total)}) au nom de ${checkoutData.first || ''} ${checkoutData.last || ''}, livraison à ${checkoutData.city || ''}.`;
    el.innerHTML = `
      <div class="confirmation">
        <div class="confirmation__icon"><svg viewBox="0 0 24 24" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg></div>
        <h3>Order Confirmed</h3>
        <p>Merci ${checkoutData.first || ''} — votre commande MERVEX a bien été enregistrée. Notre équipe vous contactera pour confirmer la livraison à ${checkoutData.city || 'votre adresse'}.</p>
        <a class="btn btn--wa btn--block" href="${waLink(orderMsg)}" target="_blank" rel="noopener">Chat on WhatsApp</a>
        <button class="btn btn--outline btn--block" id="closeConfirm" style="margin-top:12px;">Continue Shopping</button>
      </div>`;
    document.getElementById("closeConfirm").addEventListener("click", () => closeModal("checkout"));
  }
}

// ============================================================
// SEARCH
// ============================================================
function renderSearchResults(query){
  const wrap = document.getElementById("searchResults");
  if (!query){ wrap.innerHTML = ""; return; }
  const q = query.toLowerCase();
  const list = products.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.category.toLowerCase().includes(q) ||
    (p.category === "bags" && "bag".includes(q)) ||
    (p.category === "watches" && "watch".includes(q)) ||
    (p.category === "caps" && "cap".includes(q)) ||
    (p.category === "accessories" && "accessory".includes(q)) ||
    "street".includes(q) && p.category === "bags"
  );
  if (list.length === 0){
    wrap.innerHTML = `<p class="empty-state" style="grid-column:1/-1;">NO PRODUCTS FOUND</p>`;
    return;
  }
  wrap.innerHTML = list.slice(0, 8).map(p => `
    <a href="#bestsellers" class="search-result" data-goto="${p.id}" style="display:flex;flex-direction:column;gap:8px;">
      <img src="${p.image}" alt="${p.name}" style="aspect-ratio:4/5;object-fit:cover;">
      <span style="font-family:var(--font-display);font-size:14px;">${p.name}</span>
      <span style="font-size:12px;color:var(--text-dim);">${formatMAD(p.price)}</span>
    </a>`).join("");

  wrap.querySelectorAll("[data-goto]").forEach(a => a.addEventListener("click", () => {
    document.getElementById("searchPanel").classList.remove("is-open");
    setTimeout(() => openQuickView(parseInt(a.dataset.goto)), 300);
  }));
}

// ============================================================
// COUNTDOWN
// ============================================================
function startCountdown(){
  let target = new Date().getTime() + ((23*24*3600) + (14*3600) + (51*60) + 9) * 1000;
  function tick(){
    const now = new Date().getTime();
    let diff = Math.max(0, target - now);
    const days = Math.floor(diff / (1000*60*60*24));
    const hours = Math.floor((diff % (1000*60*60*24)) / (1000*60*60));
    const mins = Math.floor((diff % (1000*60*60)) / (1000*60));
    const secs = Math.floor((diff % (1000*60)) / 1000);
    document.getElementById("cd-days").textContent = String(days).padStart(2,"0");
    document.getElementById("cd-hours").textContent = String(hours).padStart(2,"0");
    document.getElementById("cd-mins").textContent = String(mins).padStart(2,"0");
    document.getElementById("cd-secs").textContent = String(secs).padStart(2,"0");
  }
  tick();
  setInterval(tick, 1000);
}

// ============================================================
// REVIEWS SLIDER
// ============================================================
let reviewIndex = 0;
function initReviews(){
  const track = document.getElementById("reviewsTrack");
  const dots = document.getElementById("reviewsDots");
  track.innerHTML = reviews.map(r => `
    <div class="review-card">
      <div class="review-card__stars">★★★★★</div>
      <p class="review-card__text">"${r.text}"</p>
      <p class="review-card__author">— ${r.author}</p>
    </div>`).join("");
  dots.innerHTML = reviews.map((_, i) => `<button data-dot="${i}" class="${i === 0 ? 'is-active' : ''}"></button>`).join("");

  dots.querySelectorAll("[data-dot]").forEach(d => d.addEventListener("click", () => {
    reviewIndex = parseInt(d.dataset.dot);
    updateReviewSlider();
  }));

  setInterval(() => {
    reviewIndex = (reviewIndex + 1) % reviews.length;
    updateReviewSlider();
  }, 5000);
}
function updateReviewSlider(){
  document.getElementById("reviewsTrack").style.transform = `translateX(-${reviewIndex * 100}%)`;
  document.querySelectorAll("#reviewsDots button").forEach((d, i) => d.classList.toggle("is-active", i === reviewIndex));
}

// ============================================================
// THEME (dark/light)
// ============================================================
function initTheme(){
  const saved = localStorage.getItem("mervex_theme") || "dark";
  if (saved === "light") document.documentElement.setAttribute("data-theme", "light");
  document.getElementById("themeBtn").addEventListener("click", () => {
    const isLight = document.documentElement.getAttribute("data-theme") === "light";
    if (isLight){
      document.documentElement.removeAttribute("data-theme");
      localStorage.setItem("mervex_theme", "dark");
    } else {
      document.documentElement.setAttribute("data-theme", "light");
      localStorage.setItem("mervex_theme", "light");
    }
  });
}

// ============================================================
// NAVBAR SCROLL STATE
// ============================================================
function initNavScroll(){
  const nav = document.getElementById("nav");
  function onScroll(){ nav.classList.toggle("is-scrolled", window.scrollY > 40); }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
}

// ============================================================
// MOBILE MENU + BURGER
// ============================================================
function initMobileMenu(){
  const burger = document.getElementById("burgerBtn");
  const menu = document.getElementById("mobileMenu");
  const overlay = document.getElementById("overlay");

  burger.addEventListener("click", () => {
    const isOpen = menu.classList.toggle("is-open");
    burger.classList.toggle("is-active", isOpen);
    burger.setAttribute("aria-expanded", String(isOpen));
    overlay.classList.toggle("is-open", isOpen);
    document.body.style.overflow = isOpen ? "hidden" : "";
  });

  menu.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    menu.classList.remove("is-open");
    burger.classList.remove("is-active");
    overlay.classList.remove("is-open");
    document.body.style.overflow = "";
  }));
}

// ============================================================
// CATEGORY LINKS -> FILTER
// ============================================================
function initCategoryLinks(){
  document.querySelectorAll("[data-cat]").forEach(a => {
    a.addEventListener("click", (e) => {
      e.preventDefault();
      activeFilters.category = a.dataset.cat;
      document.getElementById("catFilter").value = a.dataset.cat;
      renderProductGrid();
      closeAllOverlays();
      document.getElementById("shop").scrollIntoView({ behavior: "smooth" });
    });
  });
}

// ============================================================
// 3D SHOWROOM — cinematic scroll-driven product journey
// ============================================================
function initShowroom(){
  const showroom = document.getElementById("showroom");
  const viewport = document.getElementById("showroomViewport");
  if (!showroom || !viewport) return;

  const scenes = Array.from(viewport.querySelectorAll(".scene"));
  const dots = Array.from(viewport.querySelectorAll(".showroom__dot"));
  const scrollHint = document.getElementById("showroomScrollHint");
  const numScenes = scenes.length;

  const mqMobile = window.matchMedia("(max-width: 900px)");
  const mqReduced = window.matchMedia("(prefers-reduced-motion: reduce)");
  let isMobile = mqMobile.matches;
  let reducedMotion = mqReduced.matches;

  let showroomTop = 0;
  let showroomHeight = 0;
  let viewportH = window.innerHeight;
  let isInView = false;
  let rafId = null;
  let lastActiveIndex = -1;
  let introPlayed = false;
  let introLocal = null; // overrides scene-0 local progress during load-in animation

  // Smoothed pointer parallax (desktop only)
  let pointerX = 0, pointerY = 0, smoothX = 0, smoothY = 0;

  function measure(){
    const rect = showroom.getBoundingClientRect();
    showroomTop = window.scrollY + rect.top;
    showroomHeight = showroom.offsetHeight;
    viewportH = window.innerHeight;
  }

  function computeProgress(){
    const scrollable = showroomHeight - viewportH;
    if (scrollable <= 0) return 0;
    const raw = (window.scrollY - showroomTop) / scrollable;
    // Map to [0, numScenes-1] so the final scene settles centered at the
    // bottom of the scroll runway instead of continuing to exit past it.
    return Math.min(Math.max(raw, 0), 1) * (numScenes - 1);
  }

  // Apply the 3D transform for one scene given its local progress (-1..1, 0 = centered)
  function applyScene(scene, local, isActive){
    const stage = scene.querySelector(".scene__stage");
    const glow = scene.querySelector(".scene__glow");
    const textInner = scene.querySelector(".scene__text-inner");
    const clamped = Math.max(-1, Math.min(1, local));

    let tz, ty, rotY, scale;
    if (clamped <= 0){
      // entering: deep background (-1) -> centered focus (0)
      const t = 1 + clamped; // 0..1
      const eased = t * t * (3 - 2 * t); // smoothstep
      tz = -900 * (1 - eased);
      ty = isMobile ? 0 : 40 * (1 - eased);
      rotY = isMobile ? 0 : 18 * (1 - eased);
      scale = 0.55 + 0.45 * eased;
    } else {
      // exiting: centered (0) -> moved past viewer, fading (1)
      const t = clamped; // 0..1
      const eased = t * t * (3 - 2 * t);
      tz = 260 * eased;
      ty = isMobile ? 0 : -30 * eased;
      rotY = isMobile ? 0 : -14 * eased;
      scale = 1 + 0.35 * eased;
    }

    // Mouse-follow tilt, only on the currently centered/active scene, desktop only
    let tiltX = 0, tiltY = 0;
    if (isActive && !isMobile && !reducedMotion){
      tiltY = smoothX * 6;
      tiltX = -smoothY * 4;
    }

    if (stage){
      stage.style.transform =
        `translate3d(0, ${ty}px, ${tz}px) rotate3d(0,1,0, ${(rotY + tiltY).toFixed(2)}deg) rotate3d(1,0,0, ${tiltX.toFixed(2)}deg) scale3d(${scale.toFixed(3)}, ${scale.toFixed(3)}, 1)`;
    }
    if (glow){
      glow.style.opacity = Math.max(0, 1 - Math.abs(clamped) * 1.3);
    }
    if (textInner){
      const textOpacity = Math.max(0, 1 - Math.abs(clamped) * 2.4);
      const textShift = clamped * 36;
      textInner.style.opacity = textOpacity;
      textInner.style.transform = `translate3d(0, ${textShift}px, 0)`;
    }
    scene.style.opacity = Math.max(0, 1 - Math.abs(clamped) * 1.05);
  }

  function render(){
    const progress = computeProgress();
    const activeIndex = Math.min(Math.floor(progress), numScenes - 1);

    if (activeIndex !== lastActiveIndex){
      dots.forEach((d, i) => d.classList.toggle("is-active", i === activeIndex));
      if (scrollHint) scrollHint.classList.toggle("is-hidden", progress > 0.06);
      lastActiveIndex = activeIndex;
    }

    scenes.forEach((scene, i) => {
      const isAdjacent = Math.abs(i - activeIndex) <= 1;
      if (!isAdjacent){
        if (scene.classList.contains("is-tracked")){
          scene.classList.remove("is-tracked", "is-active");
          scene.style.opacity = 0;
        }
        return;
      }
      scene.classList.add("is-tracked");
      const isActive = i === activeIndex;
      scene.classList.toggle("is-active", isActive);

      let local = progress - i;
      if (i === 0 && introLocal !== null) local = introLocal;
      applyScene(scene, local, isActive);
    });

    if (!isMobile && !reducedMotion){
      smoothX += (pointerX - smoothX) * 0.08;
      smoothY += (pointerY - smoothY) * 0.08;
    }
  }

  function loop(){
    render();
    if (isInView) rafId = requestAnimationFrame(loop);
    else rafId = null;
  }
  function startLoop(){
    if (rafId === null) rafId = requestAnimationFrame(loop);
  }

  function playIntro(){
    if (introPlayed || reducedMotion) return;
    introPlayed = true;
    const duration = 1400;
    const start = performance.now();
    function step(now){
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      introLocal = -1 + eased;
      if (t < 1) requestAnimationFrame(step);
      else introLocal = null;
    }
    requestAnimationFrame(step);
  }

  measure();
  render();

  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      isInView = entry.isIntersecting;
      if (isInView){
        startLoop();
        if (window.scrollY < 60) playIntro();
      }
    });
  }, { threshold: 0 });
  io.observe(showroom);

  window.addEventListener("resize", () => {
    isMobile = mqMobile.matches;
    reducedMotion = mqReduced.matches;
    measure();
  });

  if (!isMobile){
    window.addEventListener("pointermove", (e) => {
      pointerX = (e.clientX / window.innerWidth - 0.5) * 2;
      pointerY = (e.clientY / window.innerHeight - 0.5) * 2;
    }, { passive: true });
  }

  // CTA wiring: jump to a category filter within the shop grid
  viewport.querySelectorAll("[data-goto-cat]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const cat = btn.dataset.gotoCat;
      activeFilters.category = cat;
      const catSelect = document.getElementById("catFilter");
      if (catSelect) catSelect.value = cat;
      renderProductGrid();
      document.getElementById("shop").scrollIntoView({ behavior: "smooth" });
    });
  });
  // CTA wiring: jump to a named section
  viewport.querySelectorAll("[data-goto-section]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = document.getElementById(btn.dataset.gotoSection);
      if (target) target.scrollIntoView({ behavior: "smooth" });
    });
  });
}

// ============================================================
// SCROLL REVEAL
// ============================================================
let revealObserver;
function observeReveals(){
  if (!revealObserver){
    revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          entry.target.classList.add("is-visible");
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
  }
  document.querySelectorAll(".reveal:not(.is-visible)").forEach(el => revealObserver.observe(el));
}

// ============================================================
// FILTER TOOLBAR WIRING
// ============================================================
function initToolbar(){
  const catFilter = document.getElementById("catFilter");
  const priceFilter = document.getElementById("priceFilter");
  const priceVal = document.getElementById("priceVal");
  const ratingFilter = document.getElementById("ratingFilter");
  const sortSelect = document.getElementById("sortSelect");
  const colorButtons = document.querySelectorAll("#colorFilter .pill");
  const clearBtn = document.getElementById("clearFilters");
  const filterToggle = document.getElementById("filterToggle");
  const toolbar = document.getElementById("toolbar");

  catFilter.addEventListener("change", () => { activeFilters.category = catFilter.value; renderProductGrid(); });
  priceFilter.addEventListener("input", () => {
    activeFilters.price = parseInt(priceFilter.value);
    priceVal.textContent = priceFilter.value;
    renderProductGrid();
  });
  ratingFilter.addEventListener("change", () => { activeFilters.rating = parseFloat(ratingFilter.value); renderProductGrid(); });
  sortSelect.addEventListener("change", () => { activeFilters.sort = sortSelect.value; renderProductGrid(); });

  colorButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const color = btn.dataset.color;
      btn.classList.toggle("is-active");
      if (activeFilters.colors.includes(color)){
        activeFilters.colors = activeFilters.colors.filter(c => c !== color);
      } else {
        activeFilters.colors.push(color);
      }
      renderProductGrid();
    });
  });

  clearBtn.addEventListener("click", () => {
    activeFilters = { category: "all", price: 2000, colors: [], rating: 0, sort: "featured", query: "" };
    catFilter.value = "all";
    priceFilter.value = 2000;
    priceVal.textContent = "2000";
    ratingFilter.value = "0";
    sortSelect.value = "featured";
    colorButtons.forEach(b => b.classList.remove("is-active"));
    renderProductGrid();
    showToast("Filters cleared");
  });

  filterToggle.addEventListener("click", () => toolbar.classList.toggle("is-open"));
}

// ============================================================
// MAIN EVENT WIRING
// ============================================================
function initEvents(){
  // Cart / wishlist open
  document.getElementById("cartBtn").addEventListener("click", () => openDrawer("cartDrawer"));
  document.getElementById("wishlistBtn").addEventListener("click", () => openDrawer("wishlistDrawer"));
  document.getElementById("accountBtn").addEventListener("click", () => openModal("accountModal"));
  document.getElementById("checkoutBtn").addEventListener("click", openCheckout);

  // Close buttons (drawers + modals share data-close)
  document.querySelectorAll("[data-close]").forEach(btn => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.close;
      if (key === "cart" || key === "wishlist") closeDrawer(key);
      else closeModal(key);
    });
  });
  document.getElementById("overlay").addEventListener("click", closeAllOverlays);

  // Close modals by clicking backdrop
  document.querySelectorAll(".modal").forEach(modal => {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) modal.classList.remove("is-open");
    });
  });

  // Escape key closes everything
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape"){
      closeAllOverlays();
      document.querySelectorAll(".modal.is-open").forEach(m => m.classList.remove("is-open"));
      document.getElementById("searchPanel").classList.remove("is-open");
    }
  });

  // Search
  const searchBtn = document.getElementById("searchBtn");
  const searchPanel = document.getElementById("searchPanel");
  const searchInput = document.getElementById("searchInput");
  const searchClose = document.getElementById("searchClose");
  searchBtn.addEventListener("click", () => {
    searchPanel.classList.toggle("is-open");
    if (searchPanel.classList.contains("is-open")) setTimeout(() => searchInput.focus(), 300);
  });
  searchClose.addEventListener("click", () => searchPanel.classList.remove("is-open"));
  searchInput.addEventListener("input", () => renderSearchResults(searchInput.value.trim()));

  // Gift experience
  document.getElementById("giftDiscoverBtn").addEventListener("click", () => openModal("giftModal"));

  // Newsletter
  document.getElementById("newsletterForm").addEventListener("submit", (e) => {
    e.preventDefault();
    e.target.reset();
    showToast("Subscribed ✓");
  });

  // Login form
  document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    showToast("Logged in ✓");
    closeModal("account");
  });
  document.getElementById("createAccountBtn").addEventListener("click", () => showToast("Account creation coming soon"));

  // WhatsApp CTA links (build dynamically so number stays centralized)
  document.getElementById("waCtaBtn").href = waLink("Bonjour MERVEX, j'ai besoin d'aide pour choisir un produit.");
  document.getElementById("contactWa").href = waLink("Bonjour MERVEX, j'ai une question.");
}

// ============================================================
// LOADER
// ============================================================
function initLoader(){
  window.addEventListener("load", () => {
    setTimeout(() => {
      document.getElementById("loader").classList.add("is-hidden");
    }, 500);
  });
  // Fallback in case load already fired
  setTimeout(() => document.getElementById("loader").classList.add("is-hidden"), 2500);
}

// ============================================================
// INIT
// ============================================================
document.addEventListener("DOMContentLoaded", async () => {
  await loadProductsFromAPI();
  initLoader();
  initTheme();
  initNavScroll();
  initMobileMenu();
  initCategoryLinks();
  initShowroom();
  initToolbar();
  initEvents();

  renderProductGrid();
  renderNewArrivals();
  renderCart();
  renderWishlist();
  startCountdown();
  initReviews();
  observeReveals();
});
