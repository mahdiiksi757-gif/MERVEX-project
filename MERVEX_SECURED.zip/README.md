# MERVEX — Dashboard connecté

## تشغيل محلي
1. Install Node.js (18+).
2. افتح Terminal داخل هذا المجلد.
3. شغّل:
   `npm install`
4. ثم:
   `npm start`
5. افتح:
   `http://localhost:3000/` للـboutique
   `http://localhost:3000/dashboard.html` للـDashboard

## الربط
- المنتجات في `db.json` وتتبدل من Dashboard.
- الطلبات من checkout في الموقع كتدخل مباشرة للـDashboard.
- stock كينقص أوتوماتيكياً بعد الطلب.
- العملاء كيتسجلو أوتوماتيكياً.
- البيانات دائمة في `db.json`.

ملاحظة: قبل النشر online خاصك تستعمل قاعدة بيانات حقيقية (PostgreSQL/MySQL/Supabase مثلاً) بدل JSON، وتضيف login/admin authentication.
