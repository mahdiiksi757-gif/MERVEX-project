const express = require("express");
const fs = require("fs");
const path = require("path");
const helmet = require("helmet");
const compression = require("compression");
const rateLimit = require("express-rate-limit");
const auth = require("basic-auth");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;

// FIX 2: DB path قابل للتحكم عبر environment variable.
// فـ Render، ضبط DB_PATH=/app/data/db.json (فولدر الـ persistent disk) باش
// التعديلات (منتجات/طلبات) ما تضيعش مع كل deploy أو restart.
// إلا ماكانش DB_PATH محدد، كيستعمل db.json المحلي (يخدم فـ localhost فقط).
const DB_FILE = process.env.DB_PATH
  ? path.resolve(process.env.DB_PATH)
  : path.join(ROOT, "db.json");

// إلا كان DB_PATH فولدر جديد وماكاين فيه ملف، نسخو db.json الأصلي كـ seed أولي
(function ensureDbFile() {
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const seed = path.join(ROOT, "db.json");
    if (fs.existsSync(seed) && path.resolve(seed) !== DB_FILE) {
      fs.copyFileSync(seed, DB_FILE);
      console.log(`db.json initialisé depuis le seed vers ${DB_FILE}`);
    } else {
      fs.writeFileSync(DB_FILE, JSON.stringify({ products: [], orders: [], customers: [] }, null, 2));
    }
  }
})();

// FIX 1: headers أمنية + ضغط الردود
app.use(helmet({
  contentSecurityPolicy: false // معطل هنا لأن الموقع كيستعمل inline scripts/styles؛ فعّلها منين تنظف الكود
}));
app.use(compression());

app.use(express.json({ limit: "1mb" }));

// FIX 1: Rate limiting على كل /api باش نحميو من abuse/brute-force
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use("/api", apiLimiter);

// FIX 1: Basic auth لحماية لوحة التحكم وكل العمليات الحساسة
// خاصك تضيف ADMIN_USER و ADMIN_PASS كـ environment variables (ماشي فالكود، وماشي فـ git).
function requireAdmin(req, res, next) {
  const user = process.env.ADMIN_USER;
  const pass = process.env.ADMIN_PASS;
  if (!user || !pass) {
    console.warn("⚠️  ADMIN_USER/ADMIN_PASS ماشي محددين — لوحة التحكم بلا حماية!");
    return next(); // بلا تعطيل السيرفر محليا، ولكن خاص يتصاوب قبل production
  }
  const creds = auth(req);
  if (!creds || creds.name !== user || creds.pass !== pass) {
    res.set("WWW-Authenticate", 'Basic realm="MERVEX Admin"');
    return res.status(401).send("Authentification requise");
  }
  next();
}

// حماية صفحة الداشبورد نفسها
app.get("/dashboard.html", requireAdmin, (req, res) => {
  res.sendFile(path.join(ROOT, "dashboard.html"));
});

app.use(express.static(ROOT));

function readDB() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function writeDB(db) {
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), "utf8");
  fs.renameSync(tmp, DB_FILE);
}
function nextId(items) {
  return items.reduce((m, x) => Math.max(m, Number(x.id) || 0), 0) + 1;
}

app.get("/api/products", (req,res) => {
  res.json(readDB().products);
});

app.post("/api/products", requireAdmin, (req,res) => {
  const db = readDB();
  const b = req.body || {};
  if (!b.name || !Number.isFinite(Number(b.price))) return res.status(400).json({error:"Nom et prix requis"});
  const product = {
    id: nextId(db.products), name: String(b.name), category: String(b.category || "accessories"),
    price: Number(b.price), oldPrice: Number(b.oldPrice || 0),
    image: b.image || "./assets/images/accessories/acc-01.svg",
    rating: Number(b.rating || 0), colors: b.colors || [], sizes: b.sizes || [],
    bestseller: !!b.bestseller, newProduct: b.newProduct !== false, discount: Number(b.discount || 0),
    stock: Math.max(0, Number(b.stock || 0))
  };
  db.products.push(product); writeDB(db); res.status(201).json(product);
});

app.patch("/api/products/:id", requireAdmin, (req,res) => {
  const db = readDB(), p = db.products.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({error:"Produit introuvable"});
  Object.assign(p, req.body);
  if ("price" in p) p.price = Number(p.price);
  if ("stock" in p) p.stock = Math.max(0, Number(p.stock));
  writeDB(db); res.json(p);
});

app.delete("/api/products/:id", requireAdmin, (req,res) => {
  const db = readDB();
  db.products = db.products.filter(x => x.id !== Number(req.params.id));
  writeDB(db); res.json({ok:true});
});

// GET /api/orders كيعرض بيانات شخصية للزبناء (هاتف/عنوان) — للأدمين فقط
app.get("/api/orders", requireAdmin, (req,res) => res.json(readDB().orders));

app.patch("/api/orders/:id", requireAdmin, (req,res) => {
  const db = readDB(), o = db.orders.find(x => x.id === req.params.id);
  if (!o) return res.status(404).json({error:"Commande introuvable"});
  if (req.body.status) o.status = String(req.body.status);
  writeDB(db); res.json(o);
});

app.post("/api/orders", (req,res) => {
  const db = readDB(), b = req.body || {};
  if (!b.customer?.first || !b.customer?.phone || !b.customer?.city || !b.customer?.address)
    return res.status(400).json({error:"Informations client/livraison incomplètes"});
  if (!Array.isArray(b.items) || !b.items.length) return res.status(400).json({error:"Panier vide"});

  const items = [];
  let subtotal = 0;
  for (const item of b.items) {
    const p = db.products.find(x => x.id === Number(item.productId));
    const qty = Math.max(1, Number(item.qty || 1));
    if (!p) return res.status(400).json({error:"Produit introuvable: " + item.productId});
    if (p.stock < qty) return res.status(400).json({error:`Stock insuffisant: ${p.name}`});
    items.push({productId:p.id, name:p.name, price:p.price, qty, image:p.image});
    subtotal += p.price * qty;
  }
  for (const item of items) {
    const p = db.products.find(x => x.id === item.productId);
    p.stock -= item.qty;
  }

  const delivery = Number(b.deliveryFee || 30);
  const total = subtotal + delivery;
  const num = 1000 + db.orders.length + 1;
  const order = {
    id: `#MX-${num}`,
    createdAt: new Date().toISOString(),
    customer: b.customer,
    payment: b.payment || "cod",
    items, subtotal, delivery, total, status: "Nouvelle"
  };
  db.orders.unshift(order);

  const phone = b.customer.phone;
  let c = db.customers.find(x => x.phone === phone);
  if (!c) {
    c = {id:nextId(db.customers), first:b.customer.first, last:b.customer.last || "", phone, email:b.customer.email || "",
         ordersCount:0, totalSpent:0, lastOrderAt:null};
    db.customers.push(c);
  }
  c.first=b.customer.first; c.last=b.customer.last || c.last; c.email=b.customer.email || c.email;
  c.ordersCount += 1; c.totalSpent += total; c.lastOrderAt=order.createdAt;
  writeDB(db);
  res.status(201).json(order);
});

// بيانات الزبناء (هاتف/إيميل) حساسة — للأدمين فقط
app.get("/api/customers", requireAdmin, (req,res) => res.json(readDB().customers));

app.get("/api/stats", requireAdmin, (req,res) => {
  const db=readDB();
  const revenue=db.orders.reduce((s,o)=>s+Number(o.total||0),0);
  const units=db.orders.reduce((s,o)=>s+o.items.reduce((a,i)=>a+i.qty,0),0);
  res.json({revenue, orders:db.orders.length, customers:db.customers.length, avgOrder:db.orders.length?revenue/db.orders.length:0, units});
});

app.get("*", (req,res) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({error:"Not found"});
  res.sendFile(path.join(ROOT,"index.html"));
});

app.listen(PORT, () => console.log(`MERVEX running on http://localhost:${PORT}`));
